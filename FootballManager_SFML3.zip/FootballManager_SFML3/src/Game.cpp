#include "Game.hpp"
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <unordered_map>

namespace {
const sf::Color bg(12, 23, 35), panel(25, 42, 57), edge(41, 63, 79);
const sf::Color mint(87, 224, 160), pale(203, 223, 232), gold(255, 198, 92);
std::string rarityColorLabel(const std::string& rarity) { return rarity == "Legendary" ? "LEGENDA" : rarity == "Epic" ? "EPICKI" : rarity == "Rare" ? "RZADKI" : "ZWYKLY"; }
sf::Color rarityColor(const std::string& rarity) {
    if (rarity == "Legendary") return sf::Color(255, 200, 77);
    if (rarity == "Epic") return sf::Color(198, 133, 255);
    if (rarity == "Rare") return sf::Color(102, 190, 255);
    return sf::Color(157, 184, 193);
}
}

Game::Game()
    : window_(sf::VideoMode({1280u, 800u}), "Football Manager - Clicker", sf::Style::Titlebar | sf::Style::Close),
      players_(loadPlayers(std::string(FM_DATA_DIR) + "/players.txt")), rng_(std::random_device{}()) {
    window_.setFramerateLimit(60);
    std::vector<std::string> paths = {
        "assets/font.ttf", "../assets/font.ttf", "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/segoeui.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf"
    };
    for (const auto& path : paths) {
        if (std::filesystem::exists(path) && font_.openFromFile(path)) { hasFont_ = true; break; }
    }
    if (!hasFont_) std::cerr << "UWAGA: Nie znaleziono czcionki. Dodaj assets/font.ttf\n";
    load();
}

void Game::run() {
    sf::Clock clock;
    while (window_.isOpen()) {
        while (auto event = window_.pollEvent()) {
            if (event->is<sf::Event::Closed>()) { save(); window_.close(); }
            if (const auto* e = event->getIf<sf::Event::MouseButtonPressed>()) {
                if (e->button == sf::Mouse::Button::Left) onClick(e->position);
            }
            if (const auto* e = event->getIf<sf::Event::KeyPressed>()) {
                if (e->code == sf::Keyboard::Key::Escape) { save(); window_.close(); }
                if (e->code == sf::Keyboard::Key::Space && tab_ == Tab::Stadium) {
                    double gain = clickGain(); grass_ += gain; stats_.earned += gain; ++stats_.clicks;
                }
            }
        }
        update(std::min(0.1f, clock.restart().asSeconds()));
        draw();
    }
}

void Game::update(float dt) {
    stats_.playTime += dt;
    double gain = passiveGain() * dt;
    grass_ += gain;
    stats_.earned += gain;
    flashTimer_ = std::max(0.0, flashTimer_ - dt);
    saveTimer_ += dt;
    if (saveTimer_ >= 15.0) { save(); saveTimer_ = 0; }
}

bool Game::inside(sf::Vector2i p, float x, float y, float w, float h) {
    return p.x >= x && p.y >= y && p.x <= x + w && p.y <= y + h;
}

void Game::onClick(sf::Vector2i p) {
    // Boczne menu jest dostepne z kazdego ekranu.
    for (int i = 0; i < 5; ++i) {
        if (inside(p, 22, 188 + 83 * i, 222, 62)) { tab_ = static_cast<Tab>(i); return; }
    }
    if (inside(p, 22, 739, 222, 39)) { save(); notify("Gra zapisana!"); return; }
    if (tab_ == Tab::Stadium && inside(p, 455, 228, 525, 430)) {
        double gain = clickGain(); grass_ += gain; stats_.earned += gain; ++stats_.clicks;
        notify("+" + prettyNumber(gain) + " trawki");
    } else if (tab_ == Tab::Packs) {
        for (int i = 0; i < 3; ++i)
            if (inside(p, 310 + 310 * i, 453, 270, 62)) { openPack(i); return; }
    } else if (tab_ == Tab::Upgrades) {
        for (int i = 0; i < 3; ++i)
            if (inside(p, 946, 243 + 145 * i, 205, 56)) { buyUpgrade(i); return; }
    } else if (tab_ == Tab::Collection) {
        if (inside(p, 386, 708, 145, 46)) collectionPage_ = std::max(0, collectionPage_ - 1);
        if (inside(p, 1025, 708, 145, 46)) collectionPage_ = std::min(2, collectionPage_ + 1);
    }
}

void Game::rect(float x, float y, float w, float h, sf::Color c, float) {
    sf::RectangleShape shape({w, h}); shape.setPosition({x, y}); shape.setFillColor(c); window_.draw(shape);
}
void Game::text(const std::string& value, float x, float y, unsigned size, sf::Color c, bool bold) {
    if (!hasFont_) return;
    sf::Text t(font_, sf::String(value), size);
    t.setPosition({x, y}); t.setFillColor(c);
    if (bold) t.setStyle(sf::Text::Bold);
    window_.draw(t);
}
void Game::button(const std::string& label, float x, float y, float w, float h, bool enabled) {
    rect(x, y, w, h, enabled ? mint : edge);
    text(label, x + 16, y + (h - 25) / 2 - 3, 19, enabled ? bg : pale, true);
}

void Game::drawFrame() {
    window_.clear(bg);
    rect(0, 0, 268, 800, panel);
    rect(268, 0, 2, 800, edge);
    rect(22, 31, 52, 52, mint);
    text("FM", 31, 39, 28, bg, true);
    text("FOOTBALL", 89, 31, 23, sf::Color::White, true);
    text("MANAGER", 89, 57, 16, mint, true);
    text("CLICKER EDITION", 23, 125, 14, pale);
    const std::vector<std::string> names = {"STADION", "PACZKI", "KOLEKCJA", "ULEPSZENIA", "OSIAGNIECIA"};
    for (int i = 0; i < 5; ++i) {
        bool active = static_cast<int>(tab_) == i;
        rect(22, 188 + 83 * i, 222, 62, active ? sf::Color(47, 102, 88) : edge);
        if (active) rect(22, 188 + 83 * i, 5, 62, mint);
        text(names[i], 39, 201 + 83 * i, 19, active ? mint : pale, active);
    }
    button("ZAPISZ GRE", 22, 739, 222, 39);
    rect(296, 26, 958, 106, panel);
    text("TRAWKA", 319, 37, 15, pale);
    text(prettyNumber(grass_), 319, 60, 38, gold, true);
    text("NA KLIK", 625, 37, 15, pale);
    text(prettyNumber(clickGain()), 625, 67, 27, mint, true);
    text("NA SEKUNDE", 899, 37, 15, pale);
    text(prettyNumber(passiveGain()), 899, 67, 27, mint, true);
    rect(296, 746, 958, 37, panel);
    text(message_, 310, 751, 16, flashTimer_ > 0 ? mint : pale);
}

void Game::drawStadium() {
    text("TWOJ STADION", 304, 155, 29, sf::Color::White, true);
    text("Zdobywaj trawke klikajac pilke lub naciskajac SPACJE.", 305, 198, 17, pale);
    rect(310, 244, 670, 448, sf::Color(35, 95, 70));
    for (int i = 0; i < 8; ++i) rect(310 + i * 84, 244, 42, 448, sf::Color(40, 108, 77));
    sf::RectangleShape field({580, 362}); field.setPosition({354, 286});
    field.setFillColor(sf::Color::Transparent); field.setOutlineThickness(4);
    field.setOutlineColor(sf::Color(180, 221, 190)); window_.draw(field);
    sf::CircleShape centerCircle(93); centerCircle.setPosition({554, 374});
    centerCircle.setFillColor(sf::Color::Transparent); centerCircle.setOutlineThickness(3);
    centerCircle.setOutlineColor(sf::Color(180, 221, 190)); window_.draw(centerCircle);
    sf::CircleShape ball(112); ball.setPosition({538, 354}); ball.setFillColor(sf::Color(240, 246, 241));
    ball.setOutlineThickness(7); ball.setOutlineColor(sf::Color(15, 35, 33)); window_.draw(ball);
    sf::CircleShape center(38, 5); center.setOrigin({38, 38}); center.setPosition({650, 466});
    center.setFillColor(sf::Color(27, 41, 47)); window_.draw(center);
    for (int i = 0; i < 5; ++i) {
        const float a = static_cast<float>(i * 6.28318530718 / 5.0);
        sf::CircleShape patch(19, 5); patch.setOrigin({19, 19});
        patch.setPosition({650 + 75 * std::cos(a), 466 + 75 * std::sin(a)});
        patch.setFillColor(sf::Color(27, 41, 47)); window_.draw(patch);
    }
    text("KLIKNIJ!", 585, 604, 24, bg, true);
    rect(1000, 244, 236, 448, panel);
    text("TWOJA DRUZYNA", 1015, 260, 18, mint, true);
    text("Karty: " + std::to_string(stats_.cardsDrawn), 1015, 312, 17, pale);
    text("Klikniecia: " + std::to_string(stats_.clicks), 1015, 352, 17, pale);
    text("Bonus COMBO:", 1015, 404, 16, pale);
    text("x" + prettyNumber(comboMultiplier()), 1015, 433, 32, gold, true);
    auto active = combos();
    if (active.empty()) text("Brak aktywnych", 1015, 495, 15, pale);
    else for (std::size_t i = 0; i < active.size(); ++i) text(active[i], 1015, 490 + i * 33, 16, mint);
}

void Game::drawPacks() {
    text("SKLEP Z PACZKAMI", 304, 155, 29, sf::Color::White, true);
    text("Otwieraj paczki i zbieraj pilkarzy. Co 12 losowan gwarantowana karta EPIC+.", 305, 199, 17, pale);
    const std::vector<std::string> titles = {"PACZKA STARTOWA", "PACZKA PRO", "PACZKA ELITE"};
    const std::vector<std::string> amounts = {"1 karta", "3 karty", "5 kart"};
    const int costs[] = {100, 450, 1400};
    for (int i = 0; i < 3; ++i) {
        float x = 310 + 310 * i;
        rect(x, 260, 270, 302, panel);
        rect(x + 19, 279, 232, 134, i == 2 ? sf::Color(99, 68, 31) : i == 1 ? sf::Color(72, 49, 99) : sf::Color(33, 87, 112));
        text(i == 2 ? "ELITE" : i == 1 ? "PRO" : "START", x + 73, 323, 31, sf::Color::White, true);
        text(titles[i], x + 16, 427, 19, mint, true);
        text(amounts[i], x + 17, 460 - 8, 16, pale);
        button("OTWORZ: " + std::to_string(costs[i]), x, 453 + 0, 270, 62, grass_ >= costs[i]);
    }
    text("Od ostatniej karty EPIC+: " + std::to_string(pity_) + "/12", 311, 605, 19, gold);
    text("OSTATNIE TRAFIENIA", 311, 645, 18, pale, true);
    for (std::size_t i = 0; i < history_.size() && i < 3; ++i)
        text(history_[history_.size() - 1 - i], 312, 677 + i * 23, 15, mint);
}

void Game::drawCollection() {
    text("KOLEKCJA PILKARZY", 304, 155, 29, sf::Color::White, true);
    int distinct = 0;
    for (const auto& p : players_) if (p.copies > 0) ++distinct;
    text("Odkryto " + std::to_string(distinct) + "/" + std::to_string(players_.size()) + " pilkarzy  |  Strona " + std::to_string(collectionPage_ + 1) + "/3", 305, 198, 17, pale);
    const int start = collectionPage_ * 8;
    for (int i = 0; i < 8 && start + i < static_cast<int>(players_.size()); ++i) {
        const auto& p = players_[start + i];
        float x = 307 + (i % 4) * 236;
        float y = 248 + (i / 4) * 216;
        rect(x, y, 215, 188, panel);
        rect(x, y, 215, 7, rarityColor(p.rarity));
        text(p.copies > 0 ? p.name : "???", x + 12, y + 27, 16, p.copies > 0 ? sf::Color::White : pale, true);
        text(rarityColorLabel(p.rarity), x + 12, y + 71, 15, rarityColor(p.rarity), true);
        text("Moc: " + prettyNumber(p.power) + "/s", x + 12, y + 111, 16, pale);
        text("Posiadane: " + std::to_string(p.copies), x + 12, y + 147, 15, mint);
    }
    button("< POPRZEDNIA", 386, 708, 145, 46, collectionPage_ > 0);
    button("NASTEPNA >", 1025, 708, 145, 46, collectionPage_ < 2);
}

void Game::drawUpgrades() {
    text("ULEPSZENIA", 304, 155, 29, sf::Color::White, true);
    text("Inwestuj trawke w moc, murawke i scouting.", 305, 198, 17, pale);
    std::vector<std::unique_ptr<Upgrade>> upgrades;
    upgrades.push_back(std::make_unique<ClickUpgrade>(clickLevel_));
    upgrades.push_back(std::make_unique<GrassUpgrade>(grassLevel_));
    upgrades.push_back(std::make_unique<LuckUpgrade>(luckLevel_));
    int levels[] = {clickLevel_, grassLevel_, luckLevel_};
    for (int i = 0; i < 3; ++i) {
        float y = 232 + i * 145;
        rect(307, y, 913, 119, panel);
        text(upgrades[i]->name(), 327, y + 9, 22, mint, true);
        text(upgrades[i]->description(), 328, y + 49, 16, pale);
        text("Poziom: " + std::to_string(levels[i]), 328, y + 79, 16, gold);
        button("KUP: " + std::to_string(upgrades[i]->cost()), 946, y + 11, 205, 56,
               grass_ >= upgrades[i]->cost());
    }
    text("Murawa: x" + prettyNumber(1 + grassLevel_ * 0.25) + "  |  Scouting: +" +
         std::to_string(luckLevel_ * 2) + " pp do lepszych kart", 310, 703, 17, pale);
}

int Game::achievementsCompleted() const {
    return (stats_.clicks >= 1) + (stats_.clicks >= 100) + (stats_.earned >= 1000) +
           (stats_.openedPacks >= 1) + (stats_.cardsDrawn >= 10) + (comboMultiplier() > 1.0);
}
void Game::drawAchievements() {
    text("OSIAGNIECIA", 304, 155, 29, sf::Color::White, true);
    text("Postep: " + std::to_string(achievementsCompleted()) + "/6", 305, 198, 18, mint);
    const std::vector<std::pair<std::string,bool>> list = {
        {"Pierwszy gwizdek - kliknij 1 raz", stats_.clicks >= 1},
        {"Krol stadionu - kliknij 100 razy", stats_.clicks >= 100},
        {"Pierwszy tysiac - zarob 1000 trawki", stats_.earned >= 1000},
        {"Scout - otworz pierwsza paczke", stats_.openedPacks >= 1},
        {"Kolekcjoner - zdobadz 10 kart", stats_.cardsDrawn >= 10},
        {"Zgrany sklad - odblokuj pierwsze COMBO", comboMultiplier() > 1.0}
    };
    for (int i = 0; i < 6; ++i) {
        float y = 245 + i * 76;
        rect(309, y, 903, 60, panel);
        rect(309, y, 8, 60, list[i].second ? mint : edge);
        text(list[i].first, 336, y + 14, 18, list[i].second ? mint : pale, list[i].second);
        text(list[i].second ? "GOTOWE" : "W TOKU", 1083, y + 15, 14, list[i].second ? mint : gold, true);
    }
}
void Game::draw() {
    drawFrame();
    switch (tab_) {
        case Tab::Stadium: drawStadium(); break;
        case Tab::Packs: drawPacks(); break;
        case Tab::Collection: drawCollection(); break;
        case Tab::Upgrades: drawUpgrades(); break;
        case Tab::Achievements: drawAchievements(); break;
    }
    window_.display();
}

double Game::clickGain() const { return (1 + clickLevel_) * (1 + 0.25 * grassLevel_) * comboMultiplier(); }
bool Game::has(const std::string& name) const {
    for (const auto& p : players_) if (p.name == name && p.copies > 0) return true;
    return false;
}
std::vector<std::string> Game::combos() const {
    std::vector<std::string> out;
    if (has("Lionel Messi") && has("Neymar Jr") && has("Luis Suarez")) out.push_back("MSN x1.5");
    if (has("Cristiano Ronaldo") && has("Gareth Bale") && has("Karim Benzema")) out.push_back("BBC x1.5");
    if (has("Lionel Messi") && has("Cristiano Ronaldo")) out.push_back("GOAT Duo x2.0");
    return out;
}
double Game::comboMultiplier() const {
    double mult = 1;
    if (has("Lionel Messi") && has("Neymar Jr") && has("Luis Suarez")) mult *= 1.5;
    if (has("Cristiano Ronaldo") && has("Gareth Bale") && has("Karim Benzema")) mult *= 1.5;
    if (has("Lionel Messi") && has("Cristiano Ronaldo")) mult *= 2;
    return mult;
}
double Game::passiveGain() const {
    double result = 0;
    for (const auto& p : players_) result += p.power * p.copies;
    return result * comboMultiplier();
}

Player& Game::randomPlayer() {
    // Szanse bazowe: Common 60%, Rare 28%, Epic 10%, Legendary 2%.
    std::uniform_int_distribution<int> dist(1, 100);
    int roll = dist(rng_);
    int boost = std::min(25, luckLevel_ * 2);
    std::string rarity;
    if (pity_ >= 11) {
        rarity = roll <= 17 + boost / 2 ? "Legendary" : "Epic";
    } else if (roll <= 2 + boost / 4) rarity = "Legendary";
    else if (roll <= 12 + boost) rarity = "Epic";
    else if (roll <= 40 + boost) rarity = "Rare";
    else rarity = "Common";
    std::vector<std::size_t> candidates;
    for (std::size_t i = 0; i < players_.size(); ++i)
        if (players_[i].rarity == rarity) candidates.push_back(i);
    if (candidates.empty()) return players_.front();
    std::uniform_int_distribution<std::size_t> pick(0, candidates.size() - 1);
    return players_[candidates[pick(rng_)]];
}
void Game::openPack(int type) {
    const int costs[] = {100, 450, 1400}, counts[] = {1, 3, 5};
    if (grass_ < costs[type]) { notify("Za malo trawki!"); return; }
    grass_ -= costs[type];
    ++stats_.openedPacks;
    std::string last;
    for (int i = 0; i < counts[type]; ++i) {
        Player& p = randomPlayer();
        ++p.copies;
        ++stats_.cardsDrawn;
        if (p.rarity == "Epic" || p.rarity == "Legendary") pity_ = 0;
        else ++pity_;
        last = p.name + " [" + rarityColorLabel(p.rarity) + "]";
        history_.push_back(last);
        if (history_.size() > 20) history_.erase(history_.begin());
    }
    notify("Zdobyto " + std::to_string(counts[type]) + " kart! Ostatnia: " + last);
    save();
}
void Game::buyUpgrade(int type) {
    std::unique_ptr<Upgrade> upgrade;
    if (type == 0) upgrade = std::make_unique<ClickUpgrade>(clickLevel_);
    if (type == 1) upgrade = std::make_unique<GrassUpgrade>(grassLevel_);
    if (type == 2) upgrade = std::make_unique<LuckUpgrade>(luckLevel_);
    if (!upgrade) return;
    if (grass_ < upgrade->cost()) { notify("Za malo trawki!"); return; }
    grass_ -= upgrade->cost();
    std::string name = upgrade->name();
    upgrade->apply(clickLevel_, grassLevel_, luckLevel_); // wywolanie polimorficzne
    notify("Kupiono: " + name);
    save();
}
void Game::notify(const std::string& value) { message_ = value; flashTimer_ = 2.0; }

void Game::save() const {
    // Format liniowy z wersja; ignoruje nieznane wpisy wczytywane przez load().
    std::ofstream out("save.txt", std::ios::trunc);
    if (!out) { std::cerr << "Nie mozna zapisac save.txt\n"; return; }
    out << "FM_SAVE_V1\n" << std::setprecision(17);
    out << "grass " << grass_ << '\n' << "clickLevel " << clickLevel_ << '\n'
        << "grassLevel " << grassLevel_ << '\n' << "luckLevel " << luckLevel_ << '\n'
        << "pity " << pity_ << '\n' << "earned " << stats_.earned << '\n'
        << "clicks " << stats_.clicks << '\n' << "openedPacks " << stats_.openedPacks << '\n'
        << "cardsDrawn " << stats_.cardsDrawn << '\n' << "playTime " << stats_.playTime << '\n';
    for (const auto& p : players_) out << "player " << std::quoted(p.name) << ' ' << p.copies << '\n';
    // Raport tekstowy jest generowany przy zapisie.
    std::ofstream report("raport.txt", std::ios::trunc);
    if (report) {
        report << "FOOTBALL MANAGER - RAPORT\n=========================\n";
        report << "Trawka: " << grass_ << "\nZarobione: " << stats_.earned
               << "\nKlikniecia: " << stats_.clicks << "\nPaczki: " << stats_.openedPacks
               << "\nKarty: " << stats_.cardsDrawn << "\nMoc/s: " << passiveGain()
               << "\nCombo: x" << comboMultiplier() << "\nOsiagniecia: " << achievementsCompleted() << "/6\n";
        report << "\nKOLEKCJA\n";
        for (const auto& p : players_) if (p.copies > 0) report << p.name << " x" << p.copies << '\n';
    }
}
void Game::load() {
    std::ifstream in("save.txt");
    std::string magic;
    if (!(in >> magic) || magic != "FM_SAVE_V1") return;
    std::string key;
    while (in >> key) {
        if (key == "grass") in >> grass_;
        else if (key == "clickLevel") in >> clickLevel_;
        else if (key == "grassLevel") in >> grassLevel_;
        else if (key == "luckLevel") in >> luckLevel_;
        else if (key == "pity") in >> pity_;
        else if (key == "earned") in >> stats_.earned;
        else if (key == "clicks") in >> stats_.clicks;
        else if (key == "openedPacks") in >> stats_.openedPacks;
        else if (key == "cardsDrawn") in >> stats_.cardsDrawn;
        else if (key == "playTime") in >> stats_.playTime;
        else if (key == "player") {
            std::string name; int copies;
            if (in >> std::quoted(name) >> copies) {
                for (auto& p : players_) if (p.name == name) { p.copies = std::max(0, copies); break; }
            }
        } else { std::string ignored; std::getline(in, ignored); }
        if (!in) break;
    }
    grass_ = std::max(0.0, grass_);
    clickLevel_ = std::clamp(clickLevel_, 0, 10000);
    grassLevel_ = std::clamp(grassLevel_, 0, 10000);
    luckLevel_ = std::clamp(luckLevel_, 0, 10000);
    pity_ = std::clamp(pity_, 0, 11);
}
