#include "Game.hpp"
#include <exception>
#include <iostream>
int main() {
    try { Game game; game.run(); }
    catch (const std::exception& e) { std::cerr << "Blad uruchomienia: " << e.what() << '\n'; return 1; }
    return 0;
}
