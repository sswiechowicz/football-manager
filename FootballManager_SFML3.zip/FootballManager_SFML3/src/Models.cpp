#include "Models.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>

std::string ClickUpgrade::name() const { return "Moc klikniecia"; }
std::string ClickUpgrade::description() const { return "+1 za kazde klikniecie"; }
int ClickUpgrade::cost() const { return 35 + level_ * 40 + level_ * level_ * 15; }
void ClickUpgrade::apply(int& clickLevel, int&, int&) const { ++clickLevel; }

std::string GrassUpgrade::name() const { return "Lepsza murawa"; }
std::string GrassUpgrade::description() const { return "+25% do zarobku z klikniec"; }
int GrassUpgrade::cost() const { return 120 + level_ * 115 + level_ * level_ * 55; }
void GrassUpgrade::apply(int&, int& grassLevel, int&) const { ++grassLevel; }

std::string LuckUpgrade::name() const { return "Szczescie scouta"; }
std::string LuckUpgrade::description() const { return "Wieksza szansa na rzadkie karty"; }
int LuckUpgrade::cost() const { return 220 + level_ * 210 + level_ * level_ * 100; }
void LuckUpgrade::apply(int&, int&, int& luckLevel) const { ++luckLevel; }

std::vector<Player> loadPlayers(const std::string& path) {
    std::ifstream file(path);
    if (!file) throw std::runtime_error("Nie mozna otworzyc: " + path);
    std::vector<Player> out;
    std::string line;
    while (std::getline(file, line)) {
        if (line.empty() || line.front() == '#') continue;
        std::istringstream ss(line);
        std::string name, rarity, powerStr;
        if (!std::getline(ss, name, '|') || !std::getline(ss, rarity, '|') ||
            !std::getline(ss, powerStr)) continue;
        try { out.push_back({name, rarity, std::stod(powerStr), 0}); }
        catch (const std::exception&) { /* pomijamy niepoprawny wiersz */ }
    }
    if (out.empty()) throw std::runtime_error("Lista zawodnikow jest pusta.");
    return out;
}

std::string prettyNumber(double amount) {
    static const char* suffix[] = {"", "K", "M", "B", "T"};
    int i = 0;
    while (std::abs(amount) >= 1000.0 && i < 4) { amount /= 1000.0; ++i; }
    std::ostringstream ss;
    ss << std::fixed << std::setprecision((i > 0 || std::abs(amount) < 100) ? 1 : 0)
       << amount << suffix[i];
    return ss.str();
}
