cmake_minimum_required(VERSION 3.25)
project(FootballManager LANGUAGES CXX VERSION 1.0)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# SFML 3 (https://www.sfml-dev.org/). Install it or provide SFML_DIR to CMake.
find_package(SFML 3 COMPONENTS Graphics Window System REQUIRED)
add_executable(FootballManager
    src/main.cpp
    src/Game.cpp
    src/Models.cpp
)
target_include_directories(FootballManager PRIVATE include)
target_link_libraries(FootballManager PRIVATE SFML::Graphics SFML::Window SFML::System)
target_compile_definitions(FootballManager PRIVATE FM_DATA_DIR="${CMAKE_CURRENT_SOURCE_DIR}/data")
if(MSVC)
    target_compile_options(FootballManager PRIVATE /W4)
else()
    target_compile_options(FootballManager PRIVATE -Wall -Wextra -Wpedantic)
endif()
