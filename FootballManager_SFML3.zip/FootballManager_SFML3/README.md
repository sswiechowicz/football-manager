# Football Manager - Clicker (C++ / SFML 3)

Gotowy projekt gry typu clicker z interfejsem graficznym SFML 3, przeznaczony do CLion.

## Wymagania
- Kompilator zgodny z C++17 (GCC, Clang albo MSVC).
- CMake 3.25 lub nowszy.
- **SFML 3.x** zainstalowane lokalnie (moduly Graphics, Window, System).
- Czcionka systemowa Arial, Segoe UI, DejaVu Sans albo Liberation Sans. Jezeli system jej nie ma, dodaj **wlasna** czcionke TTF do `assets/font.ttf` w katalogu roboczym aplikacji.

## Uruchomienie w CLion
1. Rozpakuj ZIP i wybierz **Open** w CLion, wskazujac folder `FootballManager_SFML3`.
2. Zainstaluj SFML **3** i zapewnij, ze `find_package(SFML 3 ...)` je odnajdzie. Jesli nie znajduje, ustaw w CMake Options: `-DSFML_DIR=/sciezka/do/SFML/lib/cmake/SFML` (Windows: odpowiednia sciezka do instalacji).
3. Wybierz profil CMake i uruchom cel `FootballManager`.
4. `data/players.txt` odczytywany jest ze sciezki projektu ustalonej przez CMake, wiec uruchomienie z folderu `cmake-build-debug` tez dziala.

Przy instalacji SFML przez vcpkg mozna w CLion ustawic `-DCMAKE_TOOLCHAIN_FILE=.../vcpkg/scripts/buildsystems/vcpkg.cmake` i zainstalowac `sfml` w wersji 3. Nie pobieramy automatycznie zaleznosci z internetu.

## Sterowanie
- **Klikaj pilke** na ekranie Stadion, aby zdobywac trawke; alternatywnie **SPACJA**.
- Menu po lewej: Stadion, Paczki, Kolekcja, Ulepszenia, Osiagniecia.
- W sklepie kupuj paczki Start (100, 1 karta), Pro (450, 3 karty), Elite (1400, 5 kart).
- Kupuj ulepszenia, aby zwiekszyc zarobki i szanse rzadkich kart.
- Gra zapisuje sie automatycznie co 15 sekund oraz przy zakupie, zamknieciu lub uzyciu przycisku ZAPISZ GRE.
- **ESC** - zapisz i zakoncz.

## Mechanika
- Losowanie: 60% Common, 28% Rare, 10% Epic, 2% Legendary bez ulepszen; scouting polepsza progi.
- System pity: najpozniej co 12 losowan otrzymujesz Epic lub Legendary.
- Karty generuja pasywny przychod w trawce na sekunde; kopie sumuja sie.
- COMBO: MSN (Messi, Neymar, Suarez) x1.5; BBC (Ronaldo, Bale, Benzema) x1.5; GOAT Duo (Messi, Ronaldo) x2.0. Bonusy sie mnoza i obejmuja klik oraz zarobki pasywne.
- 6 osiagniec na ekranie osiagniec; 20 zawodnikow w pliku danych.

## Pliki
- `src/main.cpp` - punkt wejscia.
- `include/Game.hpp`, `src/Game.cpp` - logika gry, interfejs, system zapisu i klasa wewnetrzna `Game::Statistics`.
- `include/Models.hpp`, `src/Models.cpp` - zawodnicy i abstrakcyjna klasa `Upgrade`, dziedziczenie, metody wirtualne i polimorfizm.
- `data/players.txt` - edytowalna baza zawodnikow.
- `CMakeLists.txt` - konfiguracja kompilacji.
- `save.txt` / `raport.txt` - tworzone w katalogu roboczym podczas gry; nie sa czescia poczatkowego ZIP.

## Uwaga
Kod jest napisany pod **SFML 3**, nie SFML 2. Nazwy klubow i pilkarzy sluza wylacznie identyfikacji w niezaleznej demonstracji edukacyjnej. Projekt nie zawiera oficjalnych logotypow ani licencjonowanych grafik.
