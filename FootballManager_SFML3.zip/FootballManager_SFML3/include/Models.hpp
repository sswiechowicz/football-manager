#pragma once
#include <string>
#include <vector>

struct Player {
    std::string name;
    std::string rarity;
    double power = 0;
    int copies = 0;
};

// Abstrakcyjna klasa bazowa + polimorfizm dla wszystkich ulepszen.
class Upgrade {
public:
    virtual ~Upgrade() = default;
    virtual std::string name() const = 0;
    virtual std::string description() const = 0;
    virtual int cost() const = 0;
    virtual void apply(int& clickLevel, int& grassLevel, int& luckLevel) const = 0;
};

class ClickUpgrade final : public Upgrade {
public:
    explicit ClickUpgrade(int level) : level_(level) {}
    std::string name() const override;
    std::string description() const override;
    int cost() const override;
    void apply(int& clickLevel, int& grassLevel, int& luckLevel) const override;
private:
    int level_;
};

class GrassUpgrade final : public Upgrade {
public:
    explicit GrassUpgrade(int level) : level_(level) {}
    std::string name() const override;
    std::string description() const override;
    int cost() const override;
    void apply(int& clickLevel, int& grassLevel, int& luckLevel) const override;
private:
    int level_;
};

class LuckUpgrade final : public Upgrade {
public:
    explicit LuckUpgrade(int level) : level_(level) {}
    std::string name() const override;
    std::string description() const override;
    int cost() const override;
    void apply(int& clickLevel, int& grassLevel, int& luckLevel) const override;
private:
    int level_;
};

std::vector<Player> loadPlayers(const std::string& path);
std::string prettyNumber(double amount);
