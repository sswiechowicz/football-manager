#pragma once
#include "Models.hpp"
#include <SFML/Graphics.hpp>
#include <memory>
#include <random>
#include <string>
#include <vector>

class Game {
public:
    // Wymagana klasa wewnetrzna.
    class Statistics {
    public:
        double earned = 0;
        int clicks = 0;
        int openedPacks = 0;
        int cardsDrawn = 0;
        double playTime = 0;
    };

    Game();
    void run();

private:
    enum class Tab { Stadium, Packs, Collection, Upgrades, Achievements };
    sf::RenderWindow window_;
    sf::Font font_;
    bool hasFont_ = false;
    Tab tab_ = Tab::Stadium;
    std::vector<Player> players_;
    std::mt19937 rng_;
    Statistics stats_;
    double grass_ = 0;
    int clickLevel_ = 0, grassLevel_ = 0, luckLevel_ = 0;
    int pity_ = 0;
    double saveTimer_ = 0;
    double flashTimer_ = 0;
    std::string message_ = "Kliknij pilke, aby zdobyc trawke!";
    std::vector<std::string> history_;
    int collectionPage_ = 0;

    void onClick(sf::Vector2i pos);
    void update(float dt);
    void draw();
    void drawStadium();
    void drawPacks();
    void drawCollection();
    void drawUpgrades();
    void drawAchievements();
    void drawFrame();
    void rect(float x, float y, float w, float h, sf::Color c, float radius = 0);
    void text(const std::string& value, float x, float y, unsigned size,
              sf::Color color = sf::Color::White, bool bold = false);
    void button(const std::string& value, float x, float y, float w, float h,
                bool enabled = true);
    static bool inside(sf::Vector2i p, float x, float y, float w, float h);
    double clickGain() const;
    double passiveGain() const;
    bool has(const std::string& name) const;
    double comboMultiplier() const;
    std::vector<std::string> combos() const;
    void openPack(int type);
    void buyUpgrade(int type);
    Player& randomPlayer();
    void notify(const std::string& value);
    void save() const;
    void load();
    int achievementsCompleted() const;
};
